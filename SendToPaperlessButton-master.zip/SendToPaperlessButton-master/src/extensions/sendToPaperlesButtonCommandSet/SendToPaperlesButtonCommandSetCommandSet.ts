import * as React from 'react';
import * as ReactDom from 'react-dom';
import { Log } from '@microsoft/sp-core-library';
import { ConsoleListener, Logger } from '@pnp/logging';
import {
  BaseListViewCommandSet,
  Command,
  IListViewCommandSetExecuteEventParameters,
  ListViewStateChangedEventArgs
} from '@microsoft/sp-listview-extensibility';
import { override } from '@microsoft/decorators';
import { ExtensionContext } from '@microsoft/sp-extension-base';
import { ICustomPanelProps, CustomPanel } from './components/CustomPanel';
import Emitter from './emitter';
import { fileTypes } from './components/CustomPanel/common';
import {IFileProps} from './components/CustomPanel/IFileProps'
import { getSP } from './pnpConfigjs';


export interface ISendToPaperlesButtonCommandSetCommandSetProperties {
  // This is an example; replace with your own properties
  paperlessURL: string;
  logLevel?: number;
}

const LOG_SOURCE: string = 'SendToPaperlesButtonCommandSetCommandSet';


export default class SendToPaperlesButtonCommandSetCommandSet extends BaseListViewCommandSet<ISendToPaperlesButtonCommandSetCommandSetProperties> {
  
  private _panelPlaceHolder: HTMLDivElement = null;
  private fileInfo: IFileProps = {};
  @override
  public onInit(): Promise<void> {
    const _setLogger = (logSource: string, properties: any, logLevel?: number) => {
      
      Logger.subscribe(new (ConsoleListener as any)(logSource));
      if (logLevel && logLevel in [0, 1, 2, 3, 99]) {
        Logger.activeLogLevel = logLevel;
      }
      Logger.write(`Initialized PanelCommandSet`);
      Logger.write(`Activated Initialized with properties:`);
      Logger.writeJSON(properties);
    }
    Log.info(LOG_SOURCE, 'Initialized SendToPaperlesButtonCommandSetCommandSet');
    _setLogger(LOG_SOURCE, this.properties, this.properties.logLevel);
    this._panelPlaceHolder = document.body.appendChild(document.createElement("div"));

    getSP(this.context);

    const compareOneCommand: Command = this.tryGetCommand('COMMAND_1');

    compareOneCommand.visible = false;

    this.context.listView.listViewStateChangedEvent.add(this, this._onListViewStateChanged);

    return Promise.resolve();
  }
  @override
  public onExecute(event: IListViewCommandSetExecuteEventParameters): void  {
      switch (event.itemId) {
      case 'COMMAND_1':
        this._showPanel();
        Emitter.emit('INPUT_FROM_MAIN', this.fileInfo);
        break;
      default:
        throw new Error('Unknown command');
    }
  }

  private _onListViewStateChanged = (args: ListViewStateChangedEventArgs): void => {
    Log.info(LOG_SOURCE, 'List view state changed');

    const compareOneCommand: Command = this.tryGetCommand('COMMAND_1');
    let showCommand: boolean = false;
    if (this.context.listView.selectedRows.length > 0) {
      
      this.fileInfo = {
        FileType: this.context.listView.selectedRows[0].getValueByName('File_x0020_Type'),
        IsFile: this.context.listView.selectedRows[0].getValueByName('FSObjType') === "0",
        ID: this.context.listView.selectedRows[0].getValueByName('ID'),
        UniqueID: this.context.listView.selectedRows[0].getValueByName('UniqueId'),
        FileName: this.context.listView.selectedRows[0].getValueByName('FileLeafRef'),
        FileURL: this.context.listView.selectedRows[0].getValueByName('FileRef'),
       
      };
      this.fileInfo.ValidFileType = fileTypes.filter((element, index, array) => { return element.toLocaleLowerCase() === this.fileInfo.FileType.toLocaleLowerCase(); }).length > 0;
      if (this.context.listView.selectedRows.length === 1 && this.fileInfo.ValidFileType && this.fileInfo.IsFile) showCommand = true;
    }

    if (compareOneCommand) {
        compareOneCommand.visible = this.context.listView.selectedRows?.length === 1 && showCommand; 
    }
    this.raiseOnChange();
  }

  private _showPanel() {
    return this._renderPanelComponent({
      context: this.context as ExtensionContext,
      paperlessURL: "https://paperless.easo.europa.eu",
      isOpen: true 
    });
  }

  private _renderPanelComponent = (props: ICustomPanelProps): void => {
    const element: React.ReactElement<ICustomPanelProps> = React.createElement(CustomPanel, props);
    ReactDom.render(element, this._panelPlaceHolder);
  }

}

