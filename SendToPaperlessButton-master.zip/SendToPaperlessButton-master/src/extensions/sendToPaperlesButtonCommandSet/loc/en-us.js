define([], function() {
  return {
    "Command1": "Command 1",
  }
});