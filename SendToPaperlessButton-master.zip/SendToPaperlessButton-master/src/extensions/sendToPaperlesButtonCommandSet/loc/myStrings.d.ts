declare interface ISendToPaperlesButtonCommandSetCommandSetStrings {
  Command1: string;

}

declare module 'SendToPaperlesButtonCommandSetCommandSetStrings' {
  const strings: ISendToPaperlesButtonCommandSetCommandSetStrings;
  export = strings;
}
