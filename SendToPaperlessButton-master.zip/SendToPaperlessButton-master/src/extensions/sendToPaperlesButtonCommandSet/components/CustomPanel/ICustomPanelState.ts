import { IFolder } from "@pnp/spfx-controls-react";
import { IDropdownOption } from "office-ui-fabric-react/lib/Dropdown";
export interface ICustomPanelState {
  isOpen: boolean;
  selectedFolder: IFolder;
  fileInfo:any;
  ddbOptions:IDropdownOption[];
  ddbOptions2:IDropdownOption[];
  selectedDDBText:string;
  selectedDDBKey:string | number;
  selectedFolderDDBText:string;
  selectedFolderDDBKey:string | number;
  profile:any[];
  selectedFolderWFID:string
  disabledDDB2:boolean;
  disabledSubmitBtn:boolean;
  sendBtnVisible:boolean;
  spinnerVisible:boolean;
}