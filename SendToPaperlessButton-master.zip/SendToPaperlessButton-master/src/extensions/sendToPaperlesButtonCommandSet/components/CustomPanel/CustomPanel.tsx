import * as React from 'react';
import styles from './CustomPanel.module.scss';
import { Panel, PanelType } from "office-ui-fabric-react/lib/Panel";
import { Dropdown, IDropdown, IDropdownOption } from "office-ui-fabric-react/lib/Dropdown";
import { ITextField,TextField} from "office-ui-fabric-react/lib/TextField";
import { Spinner} from "office-ui-fabric-react/lib/Spinner";
import { Dialog } from '@microsoft/sp-dialog';
import { PrimaryButton } from "office-ui-fabric-react/lib/Button";
import { IFolder } from '@pnp/spfx-controls-react';
import { ICustomPanelProps } from './ICustomPanelProps';
import { ICustomPanelState } from './ICustomPanelState';
import { Logger, LogLevel } from "@pnp/logging";
import { SPFI } from "@pnp/sp";
import "@pnp/sp/webs";
import "@pnp/sp/files";
import "@pnp/sp/items";
import "@pnp/sp/lists";
import "@pnp/sp/folders";
import "@pnp/sp/profiles";
import Emitter from '../../emitter';
import { getSP } from '../../pnpConfigjs';
import { Web } from 'sp-pnp-js'
import { ICustomFileState } from './ICustomFileState';
import "@pnp/sp/sites";
import { IDocumentLibraryInformation } from "@pnp/sp/sites";


export class CustomPanel extends React.Component<ICustomPanelProps, ICustomPanelState> {
  private optRef: React.RefObject<IDropdown>;
  private optRefFolders: React.RefObject<IDropdown>;
  private refTextbox: React.RefObject<ITextField>;

  
  private _sp: SPFI;
  constructor(props: ICustomPanelProps, state: ICustomPanelState) {
    super(props);
    this.optRef = React.createRef<IDropdown>();
    this.optRefFolders = React.createRef<IDropdown>();
    this.refTextbox = React.createRef<ITextField>();
    this.state = {
      isOpen: true,
      selectedFolder: null,
      fileInfo: {},
      ddbOptions: [],
      ddbOptions2: [],
      selectedDDBText: "",
      selectedDDBKey: "",
      selectedFolderDDBKey: "",
      selectedFolderDDBText: "",
      profile: [],
      disabledDDB2: true,
      disabledSubmitBtn: true,
      selectedFolderWFID:"",
      sendBtnVisible:false,
      spinnerVisible:false,
    };
    this._onDropdownChanged = this._onDropdownChanged.bind(this);
    this._onDropdown2Changed = this._onDropdown2Changed.bind(this);
    this._wfNumberEntered = this._wfNumberEntered.bind(this);
    this._sp = getSP();

  }


  public async componentWillReceiveProps(nextProps: ICustomPanelProps): Promise<void> {
    this.setState({
      isOpen: nextProps.isOpen,
    });
  }

  public async componentDidMount() {
    Emitter.on('INPUT_FROM_MAIN', (newValue) => this._getData(newValue));
    await this.makeDocumentLibraryList();
    const profileOfUser = await this._sp.profiles.myProperties();
    this.setState({ profile: profileOfUser })
  }

  public componentWillUnmount():void {
    Emitter.off('INPUT_FROM_MAIN', (newValue) => this._getData(newValue));
  }

  public _getData(data: ICustomFileState): void {
    this.setState({ fileInfo: data });
  }

  public render(): React.ReactElement<ICustomPanelProps> {
    return (
      <Panel isOpen={this.state.isOpen}
        title={'Send File to Paperless System'}
        type={PanelType.custom}
        isLightDismiss
        customWidth='400px'
        className={styles.paperlessPanel}
        onRenderFooterContent={this._onRenderFooterContent}
        onDismiss={this._closePanel}

      >
        <h2 className={styles.panelTitle}>{'Send File to Paperless System'}</h2>

        <div className={styles.listContainer}>
          <label className={styles.lb1}>Select Library:</label><Dropdown
            className={styles.dd1}
            componentRef={this.optRef}
            onChange={() => this._onDropdownChanged()}
            options={this.state.ddbOptions}
            placeholder="Select List"
            required={true}>
          </Dropdown>
          <br></br>
          <label className={styles.lb1}>Enter your Workflow ID:</label>
          <div><TextField componentRef={this.refTextbox}
            className={styles.searchFoWFBox}
            alt='Enter WF ID that was assigned to you.'
            about='Workflow Id'
            disabled={this.state.selectedDDBText === "" ? true : false}
            onChange={() => this.setState({selectedFolderWFID:this.refTextbox.current.value})}
             >              
             </TextField>
          <PrimaryButton className={styles.findBtn}
           onClick={() => this._wfNumberEntered()} 
            text="Find"
            disabled={this.state.selectedFolderWFID === "" ? true : false}/>
            {this.state.spinnerVisible &&<span className={styles.paperlessSpinner}>
             <Spinner size={2}/>
            </span>
            }
            {this.state.selectedFolderDDBText !== "" &&
             <img src="data:image/gif;base64,R0lGODlhEAAQAIQAAASCBITChESiRMzmzCSSJGSyZPT69DSaNHS6dBSKFKTSpNzu3AyGDIzGjEymTNTq1CyWLGy2bPz+/DyePHy+fP///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAABUALAAAAAAQABAAAAVmYCVWDwIxDBQ94yhFQCzHhTEazqwDk10hu12hsgjGCLDYAGh8SCA0aDBQacgIieBB8mDMsjHHALUwTHQHGYWkqAR0BGaMShIWZ4HnbvDTeXVDFQYCRjEHPhUvRjUtIg8RBEcFfCMhADs=" />
            }
          

            </div>
          <br></br>
          <label className={styles.lb2}>Select Folder:</label><Dropdown
            className={styles.dd2}
            componentRef={this.optRefFolders}
            onChange={() => this._onDropdown2Changed()}
            options={this.state.ddbOptions2}
            placeholder="Select Folder"
            required={true}>
          </Dropdown>
        </div>
      </Panel>
    );
  }

  private _onDropdownChanged(): void {
    this.setState({selectedDDBText:this.optRef.current.selectedOptions[0].text,selectedDDBKey:this.optRef.current.selectedOptions[0].key});
  }
  private _onDropdown2Changed(): void {
    this.setState({sendBtnVisible:true, selectedFolderWFID:this.optRef.current.selectedOptions[0].text,selectedFolderDDBKey:this.optRefFolders.current.selectedOptions[0].key,selectedFolderDDBText:this.optRef.current.selectedOptions[0].text});
  }

 

  private _onRenderFooterContent = () => {
    return (
      <div className={styles.footerSection}>
        <span hidden={this.state.sendBtnVisible ? false : true}>
        <PrimaryButton disabled={this.state.sendBtnVisible ? false : true} className={styles.btn1} text='Send to Paperless' onClick={() => this._sendToPaperless()} color="grey" />
        </span>
        <PrimaryButton className={styles.btn2} text="Cancel" onClick={this._closePanel} />
      </div>
    );
  }
 

  private _wfNumberEntered(): Promise<IFolder[]> {
    
    return new Promise<IFolder[]>((resolve: (res: any) => void, reject: (error: any) => void): void => {
      this.setState({spinnerVisible:true});
      const listFolderOptions: IDropdownOption[] = [];
      let MyWeb = new Web("https://paperless.easo.europa.eu");
      MyWeb.lists.getByTitle(this.state.selectedDDBText).rootFolder.folders.getByName(this.refTextbox.current.value).folders.get()
        .then((items: IFolder[]) => {
          resolve(items);
          if (items.length === 0) {
            resolve(-1);
          }
          else if (items.length > 0) {
            items.forEach((folder: IFolder) => {
              listFolderOptions.push({
                key: folder.ServerRelativeUrl,
                text: folder.Name
              });
            });
            this.setState({selectedFolderDDBKey:listFolderOptions[0].key, selectedFolderDDBText:listFolderOptions[0].text,ddbOptions2:listFolderOptions})
          }
        }, (error: any): void => {
          Dialog.alert(this.refTextbox.current.value + ' does not exist. Error code: ' + error.status);
          this.setState({selectedFolderWFID:""});
          Logger.write("Error Occured! " + error.status, LogLevel.Error);
          reject(error);
        });
        this.setState({spinnerVisible:false});
    });

    
 
  }

  public _sendToPaperless():void {
    let destinationUrl = this.state.selectedFolderDDBKey + '/' + this.state.fileInfo.FileName;
    this._sp.web.getFileByServerRelativePath(this.state.fileInfo.FileURL).copyByPath(destinationUrl, true, false).then(() => {
      Logger.write("File: " + this.state.fileInfo.FileName + ", has been sent to paperless system by: " + this.state.profile[0], LogLevel.Info);

      document.location.href = this.state.selectedFolderDDBKey + '/';
    }).catch((error: any) => {
      if(error.status === 403)
      {
      Dialog.alert('You have no permission to upload document to this folder! Error code: ' + error.status);
      }
      else {
      Dialog.alert('Error Occured! ' + error.status);
      }
      Logger.write("Error Occured! " + error.status, LogLevel.Error);
    })
  }

private async makeDocumentLibraryList() {
   
    const listOptions: IDropdownOption[] = [];
    const docLibs: IDocumentLibraryInformation[] = await this._sp.site.getDocumentLibraries("https://paperless.easo.europa.eu");
    docLibs.forEach((docLib: IDocumentLibraryInformation) => {
      listOptions.push({
        key: docLib.ServerRelativeUrl,
        text: docLib.Title.replace(/\s+/g, ' '),
      });
    });
    this.setState({ ddbOptions: listOptions })
  }
  private _closePanel = () => {
    this.setState({ isOpen: false });
  }

}
