export interface ICustomPanelProps {
  context: any;
  paperlessURL:string;
  isOpen: boolean;
}