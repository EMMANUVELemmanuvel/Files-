export interface IFileProps {
    FileName?: string;
    FileURL?: string;
    FileType?: string;
    IsFile?: boolean;
    ID?: string;
    UniqueID?: any;
    ValidFileType?: boolean;
}